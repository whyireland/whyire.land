# Whyireland Rice

![alt text](screenshot.png)

A rice made for myself, which will be named later

## Installation

I used arch for making this rice, but it'll most likely work on other distros (anything with i3 gaps)

```
1> Requirements:
	i3lock-fancy-dualmonitor
	compton
	nm-applet
	pnmixer
	alsa
	dunst (config stolen from somewhere, i'll update when found)
	feh
	firefox - https://www.reddit.com/r/FirefoxCSS/comments/7ignsk/oneline_flat_interface_dark_light/
2> File locations:
	Copy everything into your home directory
	(Remove screenshot.png)
3> Enjoy!
```
